# Vowels (a, e, i, o, u) are 5 points each.
# Special consonants (b, c, d, f, g) are 3 points each.
# All other consonants are 2 points each.

name = str(input())
vowels = ["a", "e", "i", "o", "u"]
special_con = ["b", "c", "d", "f", "g"]
score = 0
name_lst = []
for j in range(len(name)):
    name_lst.append(name)
    name_lst[j] = name[:1]
    name = name.replace(name[:1], "")

for i in range(len(name_lst)):
    if name_lst[i] in vowels:
        score += 5
    if name_lst[i] in special_con:
        score += 3
    else:
        score += 2

if score < 25:
    print("Slow")
if score >= 25 and score <= 35:
    print("Medium")
if score > 35:
    print("Fast")