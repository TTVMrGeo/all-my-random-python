s = int(input())
board_size = s * s
black_count = board_size/2

if black_count/2 == black_count//2: print(round(black_count))
else: print(round(black_count)+1)