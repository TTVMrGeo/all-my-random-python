inpts = str(input()).upper()
inpts_lst = []
final = []
a = 0

for j in range(len(inpts)):
    inpts_lst.append(inpts[:1])
    inpts = inpts[::-1]
    inpts = inpts[:-1]
    inpts = inpts[::-1]

for i in range(len(inpts_lst)):
    while inpts_lst[a] == inpts_lst[a+1]:
        a += 1
        inpts_lst.remove(inpts_lst[i])
    final.append(f"S{inpts_lst[a]}")
    
print(final)